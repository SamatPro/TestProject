create function add_datetime() returns trigger
  language plpgsql
as
$$
BEGIN
  NEW.time_creation:= now();
  RETURN NEW;
END;
$$;

alter function add_datetime() owner to postgres;

